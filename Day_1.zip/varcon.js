// Var
// String
var name = "Javascript"; 
// Number
var age = 24;
// Boolean
var canFly = false;
// Array
var languages = ['Hindi','English','Spanish'];
// Objects
var friends = {
    name:"Manan",
    hobby:"Gaming",
}

var a = 10;
console.log(a);

var a = null;
console.log(a);

// Let 
{
   let city;
   let name = "Manan"; 
   name = "Amogh";
   console.log("Using Let: ", name);
}
console.log(name)

// const - Constant

const country = "India";
console.log(country);

// country = "UK";

const _fruits = ["mango", "apple",'grapes',"pineapple"]
console.log(_fruits)
_fruits.push('cherry');
console.log(_fruits)