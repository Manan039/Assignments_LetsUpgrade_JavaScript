console.log('This will be cleared');

console.clear();
console.log('All the above content was cleared');

console.log('Manan Awasthi');

console.error('This is a simple error');

console.warn("This is a warning beware!!!!");

console.time("abc");
let fun=function(){
    console.log('This func is running');
}
let fun2=function(){
    console.log('This func2 is running');
}
fun();
fun2();
console.timeEnd('abc');


console.table({'a':1,'b':2});

for(let i =0;i<5;i++){
    console.count(i);
}

console.group('simple');
 console.warn('warning!');
 console.error('Errorrrrrr');
console.groupEnd('simple');
console.groupCollapsed('New Section');
