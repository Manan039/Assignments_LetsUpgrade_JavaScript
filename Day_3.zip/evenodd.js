let number = prompt("Enter a number",0);
console.log(number);

if(number%2==0){
    console.log(`The number entered is ${number} and the Number is even`)

}
else{
    console.log(`The number entered is ${number} and the Number is odd`)   
}