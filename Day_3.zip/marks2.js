let marks =prompt("Enter your marks",0);
if (marks>50) {
    console.log(`Marks are ${marks} and grade is A`)
    
} else if (marks==50) {
    console.log(`Marks are ${marks} and grade is B`)
} else {
    console.log(`Marks are ${marks} and grade is C`)
} 
