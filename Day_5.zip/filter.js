var lowEnd = 1;
var highEnd = prompt("Enter a positive number");
var arr = [];
while(lowEnd <= highEnd){
   console.log(arr.push(lowEnd++));
}


// // arr = [1,2,3,4,5,6];

// arr=

arr.forEach((el)=>{
    console.log(el**2)
})

// let square = arr.map((el)=>el**2);

let square = arr.map(function(el){
    return el**2;
})

console.log(square);

let even = arr.filter(el=>el%2!=0);

let evenSquares = arr.filter(el=>el%2!=0).map(el=>el**3);

console.log(even);
console.log(evenSquares);
