let sal=prompt("Enter your sales")
if (sal>0 && sal<=5000){
    console.log((sal*0.02));
}
else if (sal>5000 && sal<=10000){
    console.log((sal*0.05));
}
else if (sal>10000 && sal<=20000)
{
    console.log((sal*0.07));
}
else{
    console.log((sal*0.1));
}