let shoppinglist=['Banana','Apple','Mango','Milk'];

let additems= [...shoppinglist];
shoppinglist.push('Tea')
console.log(shoppinglist)
console.log(additems)