let n = prompt("Check for prime",1)

  if (n===1)
  {
    console.log(`${n} is not prime`);
  }
  else if(n === 2)
  {
    console.log(`${n} is  prime`);
  }else
  {
    for(var x = 2; x < n; x++)
    {
      if(n % x === 0)
      {
        console.log(`${n} is not prime`);
      }
    }
    console.log(`${n} is prime`);  
  }
