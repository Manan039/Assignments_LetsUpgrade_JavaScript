let ask = (question,yes) => alert('You agreed');
let ask = (question, no) => alert('You canceled the execution');