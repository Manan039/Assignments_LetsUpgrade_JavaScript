let age = prompt("Whats your age");
console.log(age >21 ? ` Can Drink`:`Can't Drink`)
