let Name = prompt("Whats your Name");
console.log(`Hello ${Name} how are you`);